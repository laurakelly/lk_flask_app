60 Mono Social Media Icons
by artbees (http://www.artbees.net)


Note: the company logos in these icons are copyright of their respective owners.